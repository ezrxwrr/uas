<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Leaderboard - WebDonasi</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<h2 class="page-title">Leaderboard Donatur</h2>

<div class="leaderboard-wrapper">
<table>
    <tr>
        <th>Rank</th>
        <th>Nama</th>
        <th>Badge</th>
        <th>Total Donasi</th>
        <th>Transaksi</th>
    </tr>

    <tr>
        <td>1</td>
        <td>-</td>
        <td><span class="badge badge-gold">Gold</span></td>
        <td>-</td>
        <td>-</td>
    </tr>
</table>
</div>

<div class="footer">
    <p>© 2025 WebDonasi</p>
</div>

</body>
</html>
