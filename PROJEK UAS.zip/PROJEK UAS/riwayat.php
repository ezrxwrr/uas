<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Riwayat Donasi - WebDonasi</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<h2 class="page-title">Riwayat Donasi</h2>

<table>
    <tr>
        <th>Tanggal</th>
        <th>Nominal</th>
        <th>Metode</th>
    </tr>
    <tr>
        <td>-</td>
        <td>-</td>
        <td>-</td>
    </tr>
</table>

<div style="text-align:center;">
    <a href="donasi.php" class="btn-primary">Donasi Lagi</a>
</div>

<div class="footer">
    <p>© 2025 WebDonasi</p>
</div>

</body>
</html>
